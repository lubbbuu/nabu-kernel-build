#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""nabu v14 patcher - official MiCode nabu-r-oss 4.14.180 + tiann KernelSU v1.0.5
+ SUSFS v1.5.9 (NON-GKI, TIF scheme).

Differences from the v13 patcher, and why
-----------------------------------------
v13 shipped HOSTABLE = {fs/Makefile, fs/proc/cmdline.c, fs/proc/task_mmu.c,
fs/stat.c, kernel/kallsyms.c, kernel/sys.c} - a guess made on Kuugo's fork.
That guess does not survive contact with the official tree:

  fs/Makefile             anchor is the obj-y tail; the fork had a different
                          line list, the official tree ends at 'nsfs.o'
  fs/proc/cmdline.c       fork used seq_puts+seq_putc, official uses one
                          seq_printf - the patch context does not match
  fs/proc/task_mmu.c      fork's show_vma_header_prefix ends with seq_putc(m,' ');
                          official ends the function right after seq_printf
  kernel/kallsyms.c       fork prints %px, official prints %pK with a cast

So v14 does not use a whitelist at all. It splits every hunk of
50_add into two classes:

  NEEDED     the hunk touches code that is compiled when only the 7 features
             we actually enable are on (KSU_SUSFS, SUS_KSTAT, TRY_UMOUNT,
             SPOOF_UNAME, SPOOF_CMDLINE_OR_BOOTCONFIG, HIDE_KSU_SUSFS_SYMBOLS,
             ENABLE_LOG). These MUST land or the build is wrong.
  SKIPPABLE  the hunk is a pure insertion living entirely inside
             #ifdef CONFIG_KSU_SUSFS_{SUS_PATH,SUS_MOUNT,OPEN_REDIRECT,SUS_SU,
             HAS_MAGIC_MOUNT,AUTO_ADD_*} which we keep =n. The preprocessor
             throws the inserted lines away, so the hunk is irrelevant.

NEEDED hunks that still cannot be placed are then patched by hand with exact
string anchors verified against the official source (the FIXUPS table below).
Every anchor string in FIXUPS was checked against
MiCode/Xiaomi_Kernel_OpenSource@nabu-r-oss before being written here.

Subcommands:
  apply50  <kernel_src> <50_add.patch>   needed hunks + report skipped ones
  fixups   <kernel_src>                  anchor-exact surgery for the misses
  umount   <kernel_src>                  path_umount() backport (KSU needs it)
  hooks    <kernel_src>                  KSU inline hooks (KPROBES=n path)
  ksuside  <ksu_src>                     SUSFS wiring inside KernelSU v1.0.5
  gate     <kernel_src>                  assert the ABI config is untouched
  verify   <kernel_src>                  assert every marker present
"""
import difflib
import os
import re
import sys

RATIO = 0.92

# Features we enable. Keep in sync with the yml's scripts/config block.
ENABLED = {
    "KSU_SUSFS",
    "KSU_SUSFS_SUS_KSTAT",
    "KSU_SUSFS_TRY_UMOUNT",
    "KSU_SUSFS_SPOOF_UNAME",
    "KSU_SUSFS_SPOOF_CMDLINE_OR_BOOTCONFIG",
    "KSU_SUSFS_HIDE_KSU_SUSFS_SYMBOLS",
    "KSU_SUSFS_ENABLE_LOG",
}
DISABLED = {
    "KSU_SUSFS_SUS_PATH",
    "KSU_SUSFS_SUS_MOUNT",
    "KSU_SUSFS_OPEN_REDIRECT",
    "KSU_SUSFS_SUS_SU",
    "KSU_SUSFS_HAS_MAGIC_MOUNT",
    "KSU_SUSFS_AUTO_ADD_SUS_KSU_DEFAULT_MOUNT",
    "KSU_SUSFS_AUTO_ADD_SUS_BIND_MOUNT",
    "KSU_SUSFS_AUTO_ADD_TRY_UMOUNT_FOR_BIND_MOUNT",
}

# 50_add hunks that cannot be placed by context on the official tree. Every one
# of them is re-done with an exact anchor in fixups(). Keeping the list explicit
# (instead of letting the classifier decide) means a new miss is an error rather
# than a silent skip.
HAND_FIXED = {
    "fs/Makefile",                          # obj-y tail differs from the fork
    "fs/proc/cmdline.c",                    # fork used seq_puts+seq_putc
    "fs/proc/task_mmu.c",                   # show_vma_header_prefix ends earlier
    "kernel/kallsyms.c",                    # %pK vs %px, different print
}

# Files whose 50_add hunks exist only for features this build disables. Not
# applying them is deliberate, not a failure - and they are asserted absent by
# verify() so a future accidental enable cannot slip through.
NOT_APPLICABLE = {
    "include/linux/mount.h": "susfs_mnt_id_backup is SUS_MOUNT-only, SUS_MOUNT=n",
    "include/linux/stat.h": "kstat.mnt_id is SUS_MOUNT-only, SUS_MOUNT=n",
}

# ABI-critical config: the whole point of v14. Nothing may flip these.
ABI_LOCK = {
    "CONFIG_MODULES": "y",
    "CONFIG_MODULE_UNLOAD": "y",
    "CONFIG_MODULE_SIG": "n",
    "CONFIG_MODULE_FORCE_LOAD": "n",
    "CONFIG_MODULE_FORCE_UNLOAD": "n",
    "CONFIG_MODVERSIONS": "y",
    "CONFIG_MODULES_USE_ELF_RELA": "y",
    "CONFIG_TRACEPOINTS": "y",
    "CONFIG_EVENT_TRACING": "y",
    "CONFIG_FTRACE": "y",
    "CONFIG_FUNCTION_TRACER": "n",
    "CONFIG_KPROBES": "n",
    "CONFIG_JUMP_LABEL": "n",
    "CONFIG_KALLSYMS": "y",
    "CONFIG_KALLSYMS_ALL": "y",
    "CONFIG_ARM64_MODULE_PLTS": "y",
    "CONFIG_ARM64_4K_PAGES": "y",
    "CONFIG_ARM64_VA_BITS": "39",
    "CONFIG_PREEMPT": "y",
    "CONFIG_SMP": "y",
    "CONFIG_STRICT_MODULE_RWX": "y",
    "CONFIG_RANDOMIZE_BASE": "y",
    "CONFIG_SDCARD_FS": "y",
    "CONFIG_OVERLAY_FS": "y",
    "CONFIG_THREAD_INFO_IN_TASK": "y",
    "CONFIG_USER_NS": "n",
    "CONFIG_PID_NS": "n",
    "CONFIG_PROC_KCORE": "n",
    "CONFIG_DEVMEM": "n",
    "CONFIG_TRIM_UNUSED_KSYMS": "n",
}


def _n(l):
    return l.strip()


def parse_patch(path):
    files, cur = [], None
    lines = open(path, encoding="utf-8", errors="surrogateescape").read().split("\n")
    i = 0
    while i < len(lines):
        ln = lines[i]
        m = re.match(r"^\+\+\+ b/(.+?)(?:\t.*)?$", ln)
        if m:
            cur = {"path": m.group(1).strip(), "hunks": []}
            files.append(cur)
            i += 1
            continue
        m = re.match(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(.*)", ln)
        if m and cur is not None:
            body = []
            i += 1
            while i < len(lines):
                b = lines[i]
                if b.startswith("@@") or b.startswith("diff --git") or b.startswith("--- ") or b.startswith("+++ "):
                    break
                if b[:1] in (" ", "-", "+") or b == "" or b.startswith("\\"):
                    body.append(b)
                    i += 1
                else:
                    break
            cur["hunks"].append({"start": int(m.group(1)), "body": body})
            continue
        i += 1
    return files


def split_hunk(body):
    old, new = [], []
    for b in body:
        if b.startswith("\\"):
            continue
        tag = b[:1] if b[:1] in (" ", "-", "+") else " "
        rest = b[1:]
        if tag in (" ", "-"):
            old.append(rest)
        if tag in (" ", "+"):
            new.append(rest)
    return old, new


def locate(src, old, hint):
    n = len(old)
    if n == 0:
        p = min(max(hint, 0), len(src))
        return (p, p)
    tgt = [_n(x) for x in old]
    best, br = None, 0.0
    lo, hi = max(0, hint - 600), min(len(src) - n, hint + 600)
    if hi < lo:
        lo, hi = 0, max(0, len(src) - n)
    for s in range(lo, hi + 1):
        if _n(src[s]) != tgt[0]:
            continue
        w = [_n(x) for x in src[s:s + n]]
        if len(w) != n:
            break
        r = difflib.SequenceMatcher(None, tgt, w).ratio()
        if r > br:
            br, best = r, s
            if r == 1.0:
                break
    if best is None or br < RATIO:
        for s in range(0, max(0, len(src) - n) + 1):
            if _n(src[s]) != tgt[0]:
                continue
            w = [_n(x) for x in src[s:s + n]]
            r = difflib.SequenceMatcher(None, tgt, w).ratio()
            if r > br:
                br, best = r, s
                if r == 1.0:
                    break
    if best is None or br < RATIO:
        return None
    return (best, best + n)


def read(p):
    return open(p, encoding="utf-8", errors="surrogateescape").read()


def write(p, s):
    open(p, "w", encoding="utf-8", errors="surrogateescape").write(s)


def sub(path, find, repl, marker, label, fails, count=1):
    if not os.path.isfile(path):
        fails.append("MISS FILE   %s (%s)" % (path, label))
        return False
    s = read(path)
    if marker in s:
        print("  skip  %s" % label)
        return True
    if find not in s:
        fails.append("MISS ANCHOR %s (%s)" % (path, label))
        return False
    write(path, s.replace(find, repl, count))
    print("  ok    %s" % label)
    return True


def cmd_apply10(ksu, patch, ratio=RATIO):
    """Apply the SUSFS->KernelSU patch to the KSU tree.

    10_enable_susfs_for_ksu.patch is written for exactly tiann v1.0.5: 64/64
    hunks land. A miss here means the KSU tag was bumped and the patch no longer
    matches, which is fatal - a partially patched KSU does not build.
    """
    ok = fail = 0
    fails = []
    for f in parse_patch(patch):
        path = os.path.join(ksu, f["path"])
        if not os.path.isfile(path):
            fails.append("MISS FILE %s" % f["path"])
            fail += len(f["hunks"])
            continue
        lines = read(path).split("\n")
        dirty = False
        for hi, h in enumerate(f["hunks"]):
            old, new = split_hunk(h["body"])
            loc = locate(lines, old, h["start"] - 1)
            if loc is None:
                fail += 1
                first = next((b for b in h["body"] if b[:1] in (" ", "-")), "")
                fails.append("%s #%d ctx=%r" % (f["path"], hi + 1, _n(first)[:56]))
                continue
            a, b = loc
            lines = lines[:a] + new + lines[b:]
            ok += 1
            dirty = True
        if dirty:
            write(path, "\n".join(lines))
    print("apply10: ok=%d fail=%d" % (ok, fail))
    for x in fails:
        print("   MISS", x)
    if fail:
        print("FATAL: 10_enable no longer matches this KernelSU tree.")
        print("       It is pinned to tiann v1.0.5 (64/64). Do not bump KSU_TAG")
        print("       without re-deriving this patch.")
        return 1
    return 0


# ---------------------------------------------------------------- hunk class
def hunk_guards(body):
    g = []
    for l in body:
        s = l
        if s[:1] in "+-":
            s = s[1:]
        s = s.strip()
        m = re.match(r"#\s*(?:ifdef|ifndef|if|elif)\s+(.*)", s)
        if m:
            g.append(m.group(1))
    return g


SUSFS_SYM = re.compile(r"\b(susfs_\w+|ksu_\w+|KSU_SUSFS\w*|CONFIG_KSU\w*)\b")


def _guard_names(cond):
    return set(re.findall(r"CONFIG_[A-Z0-9_]+", cond))


def hunk_class(body):
    """(needed, reason). needed=False means applying it is pointless.

    Decision order:
      1. the hunk adds no code line at all (blank / preprocessor only)
         -> nothing to compile, skip
      2. every added code line lives inside an added #if that names only
         features we keep =n -> the preprocessor deletes it, skip
      3. the added code mentions no susfs_/ksu_/KSU identifier and carries no
         guard -> it is not SUSFS work, skip
      4. otherwise the code is compiled -> needed
    """
    added = [l[1:] for l in body if l.startswith("+") and not l.startswith("+++")]
    code = [l for l in added if l.strip() and not l.strip().startswith("#")]
    if not code:
        return False, "preprocessor/blank only"

    open_guards = []
    unprotected = []
    for l in added:
        s = l.strip()
        if re.match(r"#\s*(ifdef|ifndef|if)\b", s):
            open_guards.append(_guard_names(s))
            continue
        if re.match(r"#\s*(endif)\b", s):
            if open_guards:
                open_guards.pop()
            continue
        if re.match(r"#\s*(else|elif)\b", s) or not s:
            continue
        names = set().union(*open_guards) if open_guards else set()
        if not names or (names & {("CONFIG_" + f) for f in ENABLED}):
            unprotected.append(s)

    if not unprotected:
        return False, "inserted code only under features we disable"

    if not SUSFS_SYM.search("\n".join(unprotected)):
        return False, "junk hunk - no susfs/ksu symbol in inserted code"

    toks = set()
    for g in hunk_guards(body):
        toks |= _guard_names(g)
    live = toks & {("CONFIG_" + f) for f in ENABLED}
    if live:
        return True, "touches " + ",".join(sorted(t[7:] for t in live))
    return True, "live code"


def cmd_apply50(src, patch):
    ok = fail = skip = 0
    fails, skipped = [], []
    for f in parse_patch(patch):
        p = os.path.join(src, f["path"])
        if not os.path.isfile(p):
            fail += len(f["hunks"])
            fails.append("MISSING FILE %s" % f["path"])
            continue
        s = read(p).split("\n")
        dirty = False
        for hi, h in enumerate(f["hunks"]):
            if f["path"] in HAND_FIXED:
                skip += 1
                skipped.append("%s #%d (hand-fixed in fixups())" % (f["path"], hi + 1))
                continue
            if f["path"] in NOT_APPLICABLE:
                skip += 1
                skipped.append("%s #%d (not applicable: %s)" % (f["path"], hi + 1,
                                                              NOT_APPLICABLE[f["path"]]))
                continue
            need, why = hunk_class(h["body"])
            if not need:
                skip += 1
                skipped.append("%s #%d (%s)" % (f["path"], hi + 1, why))
                continue
            old, new = split_hunk(h["body"])
            loc = locate(s, old, h["start"] - 1)
            if loc is None:
                fail += 1
                first = next((b for b in h["body"] if b[:1] in (" ", "-")), "")
                fails.append("%s #%d need=%s ctx=%r" % (f["path"], hi + 1, why, _n(first)[:56]))
                continue
            a, b = loc
            s = s[:a] + new + s[b:]
            ok += 1
            dirty = True
        if dirty:
            write(p, "\n".join(s))
    print("apply50: ok=%d fail=%d skipped=%d" % (ok, fail, skip))
    for x in skipped:
        print("   skip", x)
    for x in fails:
        print("   MISS", x)
    if fail:
        # Every expected miss lives in HAND_FIXED and is reported above as
        # "hand-fixed", never as MISS. A MISS here means the official source
        # moved and the anchors in this file need re-checking.
        print("FATAL: %d hunk(s) missed outside the hand-fixed set" % fail)
        return 1
    return 0


# ------------------------------------------------------------------- fixups
# Every anchor below was extracted from the official nabu-r-oss source.
KALLSYMS_OLD = """\t} else
\t\tseq_printf(m, "%pK %c %s\\n", (void *)iter->value,
\t\t\t   iter->type, iter->name);
\treturn 0;
}"""

KALLSYMS_NEW = """\t} else
#ifndef CONFIG_KSU_SUSFS_HIDE_KSU_SUSFS_SYMBOLS
\t\tseq_printf(m, "%pK %c %s\\n", (void *)iter->value,
\t\t\t   iter->type, iter->name);
#else
\t{
\t\tif (strstr(iter->name, "ksu_") || !strncmp(iter->name, "susfs_", 6) ||
\t\t    !strncmp(iter->name, "ksud", 4))
\t\t\treturn 0;
\t\tseq_printf(m, "%pK %c %s\\n", (void *)iter->value,
\t\t\t   iter->type, iter->name);
\t}
#endif
\treturn 0;
}"""

CMDLINE_OLD = """static int cmdline_proc_show(struct seq_file *m, void *v)
{
\tseq_printf(m, "%s\\n", saved_command_line);
\treturn 0;
}"""

CMDLINE_NEW = """#ifdef CONFIG_KSU_SUSFS_SPOOF_CMDLINE_OR_BOOTCONFIG
extern int susfs_spoof_cmdline_or_bootconfig(struct seq_file *m);
#endif

static int cmdline_proc_show(struct seq_file *m, void *v)
{
#ifdef CONFIG_KSU_SUSFS_SPOOF_CMDLINE_OR_BOOTCONFIG
\tif (!susfs_spoof_cmdline_or_bootconfig(m)) {
\t\tseq_putc(m, '\\n');
\t\treturn 0;
\t}
#endif
\tseq_printf(m, "%s\\n", saved_command_line);
\treturn 0;
}"""

# official: show_vma_header_prefix ends right after the seq_printf, so the
# extern must go after the closing brace of that function.
TMMU_OLD = """static void
show_map_vma(struct seq_file *m, struct vm_area_struct *vma, int is_pid)"""

TMMU_NEW = """#ifdef CONFIG_KSU_SUSFS_SUS_KSTAT
extern void susfs_sus_ino_for_show_map_vma(unsigned long ino, dev_t *out_dev,
\t\t\t\t\t   unsigned long *out_ino);
#endif

static void
show_map_vma(struct seq_file *m, struct vm_area_struct *vma, int is_pid)"""

TMMU_BODY_OLD = """\tif (file) {
\t\tstruct inode *inode = file_inode(vma->vm_file);
\t\tdev = inode->i_sb->s_dev;
\t\tino = inode->i_ino;
\t\tpgoff = ((loff_t)vma->vm_pgoff) << PAGE_SHIFT;
\t}"""

TMMU_BODY_NEW = """\tif (file) {
\t\tstruct inode *inode = file_inode(vma->vm_file);
#ifdef CONFIG_KSU_SUSFS_SUS_KSTAT
\t\tif (unlikely(inode->i_state & INODE_STATE_SUS_KSTAT)) {
\t\t\tsusfs_sus_ino_for_show_map_vma(inode->i_ino, &dev, &ino);
\t\t\tgoto bypass_orig_flow;
\t\t}
#endif
\t\tdev = inode->i_sb->s_dev;
\t\tino = inode->i_ino;
#ifdef CONFIG_KSU_SUSFS_SUS_KSTAT
bypass_orig_flow:
#endif
\t\tpgoff = ((loff_t)vma->vm_pgoff) << PAGE_SHIFT;
\t}"""

# stat.h: nabi v14 does NOT add kstat.mnt_id. The 50_add hunk exists for
# SUS_MOUNT (stat->mnt_id = mnt->mnt_id), and SUS_MOUNT is =n here, so the field
# would be written but never read. struct kstat is on the hot path of
# generic_fillattr/vfs_getattr and its layout is shared with the statx ABI, so
# touching it is pure risk with zero benefit. The hunk is listed in
# NOT_APPLICABLE instead.

FSMK_OLD = """\t\tpnode.o splice.o sync.o utimes.o \\
\t\tstack.o fs_struct.o statfs.o fs_pin.o nsfs.o
"""

FSMK_NEW = """\t\tpnode.o splice.o sync.o utimes.o \\
\t\tstack.o fs_struct.o statfs.o fs_pin.o nsfs.o

obj-$(CONFIG_KSU_SUSFS) += susfs.o
"""

# struct mount has no ANDROID_KABI_RESERVE in this tree (checked), so guard on
# the macro itself and fall back to an unconditional member.
MOUNT_H_OLD = """#ifdef CONFIG_KSU_SUSFS
\tANDROID_KABI_USE(4, u64 susfs_mnt_id_backup);"""


def cmd_fixups(src):
    fails = []

    sub(os.path.join(src, "kernel/kallsyms.c"), KALLSYMS_OLD, KALLSYMS_NEW,
        "CONFIG_KSU_SUSFS_HIDE_KSU_SUSFS_SYMBOLS", "kernel/kallsyms.c hide symbols", fails)
    sub(os.path.join(src, "kernel/kallsyms.c"),
        "#include <linux/compiler.h>",
        "#include <linux/compiler.h>\n#include <linux/string.h>",
        "#include <linux/string.h>", "kernel/kallsyms.c string.h", fails)

    sub(os.path.join(src, "fs/proc/cmdline.c"), CMDLINE_OLD, CMDLINE_NEW,
        "susfs_spoof_cmdline_or_bootconfig", "fs/proc/cmdline.c spoof", fails)

    sub(os.path.join(src, "fs/proc/task_mmu.c"), TMMU_OLD, TMMU_NEW,
        "extern void susfs_sus_ino_for_show_map_vma", "fs/proc/task_mmu.c decl", fails)
    sub(os.path.join(src, "fs/proc/task_mmu.c"), TMMU_BODY_OLD, TMMU_BODY_NEW,
        "susfs_sus_ino_for_show_map_vma(inode->i_ino", "fs/proc/task_mmu.c call", fails)

    sub(os.path.join(src, "fs/Makefile"), FSMK_OLD, FSMK_NEW,
        "obj-$(CONFIG_KSU_SUSFS) += susfs.o", "fs/Makefile", fails)

    # include/linux/mount.h: nabi v14 does NOT add susfs_mnt_id_backup either.
    # Every reference in susfs.c / susfs_def.h / namespace.c is inside
    # #ifdef CONFIG_KSU_SUSFS_SUS_MOUNT, which is =n. struct mount is embedded in
    # struct vfsmount, whose layout out-of-tree drivers do poke at, so leaving it
    # alone keeps the ABI bit-identical. Listed in NOT_APPLICABLE.

    print("fixups: %d unresolved" % len(fails))
    for x in fails:
        print("   FAIL", x)
    return 1 if fails else 0


# ------------------------------------------------------------------- umount
UMOUNT = r'''static int can_umount(const struct path *path, int flags)
{
	struct mount *mnt = real_mount(path->mnt);

	if (flags & ~(MNT_FORCE | MNT_DETACH | MNT_EXPIRE | UMOUNT_NOFOLLOW))
		return -EINVAL;
	if (!may_mount())
		return -EPERM;
	if (path->dentry != path->mnt->mnt_root)
		return -EINVAL;
	if (!check_mnt(mnt))
		return -EINVAL;
	if (mnt->mnt.mnt_flags & MNT_LOCKED)
		return -EINVAL;
	if (flags & MNT_FORCE && !capable(CAP_SYS_ADMIN))
		return -EPERM;
	return 0;
}

int path_umount(struct path *path, int flags)
{
	struct mount *mnt = real_mount(path->mnt);
	int ret;

	ret = can_umount(path, flags);
	if (!ret)
		ret = do_umount(mnt, flags);
	dput(path->dentry);
	mntput_no_expire(mnt);
	return ret;
}

'''

NS_TAIL = r'''
#ifdef CONFIG_KSU_SUSFS_TRY_UMOUNT
extern void susfs_try_umount_all(uid_t uid);
void susfs_run_try_umount_for_current_mnt_ns(void) {
	struct mount *mnt;
	struct mnt_namespace *mnt_ns;

	mnt_ns = current->nsproxy->mnt_ns;
	namespace_lock();
	list_for_each_entry(mnt, &mnt_ns->list, mnt_list) {
		if (mnt->mnt_id >= DEFAULT_SUS_MNT_ID) {
			change_mnt_propagation(mnt, MS_PRIVATE);
		}
	}
	namespace_unlock();
	susfs_try_umount_all(current_uid().val);
}
#endif
#ifdef CONFIG_KSU_SUSFS
bool susfs_is_mnt_devname_ksu(struct path *path) {
	struct mount *mnt;

	if (path && path->mnt) {
		mnt = real_mount(path->mnt);
		if (mnt && mnt->mnt_devname && !strcmp(mnt->mnt_devname, "KSU")) {
			return true;
		}
	}
	return false;
}
#endif
'''

NS_INC = """#if defined(CONFIG_KSU_SUSFS_SUS_MOUNT) || defined(CONFIG_KSU_SUSFS_TRY_UMOUNT)
#include <linux/susfs_def.h>
#endif
"""


def cmd_umount(src):
    fails = []
    p = os.path.join(src, "fs/namespace.c")
    if not os.path.isfile(p):
        fails.append("MISS FILE fs/namespace.c")
    else:
        s = read(p)
        if "int path_umount(struct path *path, int flags)" not in s:
            anchor = "static bool is_mnt_ns_file(struct dentry *dentry)"
            if anchor not in s:
                fails.append("MISS ANCHOR fs/namespace.c is_mnt_ns_file")
            else:
                s = s.replace(anchor, UMOUNT + anchor, 1)
                print("  ok    fs/namespace.c can_umount + path_umount")
        else:
            print("  skip  fs/namespace.c path_umount")

        if "susfs_run_try_umount_for_current_mnt_ns" not in s:
            if "susfs_def.h" not in s:
                anchor = "#include <linux/sched/task.h>\n"
                if anchor in s:
                    s = s.replace(anchor, anchor + NS_INC, 1)
                    print("  ok    fs/namespace.c include")
                else:
                    fails.append("MISS ANCHOR fs/namespace.c sched/task.h include")
            s = s.rstrip("\n") + "\n" + NS_TAIL
            print("  ok    fs/namespace.c susfs helpers")
        else:
            print("  skip  fs/namespace.c susfs helpers")
        write(p, s)

    sub(os.path.join(src, "fs/internal.h"),
        "extern void __init mnt_init(void);",
        "extern void __init mnt_init(void);\nint path_umount(struct path *path, int flags);",
        "int path_umount", "fs/internal.h", fails)

    print("umount: %d unresolved" % len(fails))
    for x in fails:
        print("   FAIL", x)
    return 1 if fails else 0


# -------------------------------------------------------------------- hooks
EXEC_DECL = """#ifdef CONFIG_KSU
extern bool ksu_execveat_hook __read_mostly;
extern int ksu_handle_execveat(int *fd, struct filename **filename_ptr,
			       void *argv, void *envp, int *flags);
extern int ksu_handle_execveat_sucompat(int *fd, struct filename **filename_ptr,
					void *argv, void *envp, int *flags);
#endif

"""

EXEC_CALL = """#ifdef CONFIG_KSU
	if (unlikely(ksu_execveat_hook))
		ksu_handle_execveat((int *)AT_FDCWD, &filename, &argv, &envp, 0);
	else
		ksu_handle_execveat_sucompat((int *)AT_FDCWD, &filename, NULL,
					     NULL, NULL);
#endif
"""

COMPAT_EXEC_CALL = """#if defined(CONFIG_KSU) && defined(CONFIG_COMPAT)
	if (!ksu_execveat_hook) /* 32-bit su */
		ksu_handle_execveat_sucompat((int *)AT_FDCWD, &filename, NULL,
					     NULL, NULL);
#endif
"""


def cmd_hooks(src):
    fails = []

    # 1. do_execve + compat_do_execve: su compat. Without these `su` in a
    #    granted app never reaches escape_to_root(). This is why KPROBES=n has
    #    to be hand-patched.
    sub(os.path.join(src, "fs/exec.c"),
        """int do_execve(struct filename *filename,
\tconst char __user *const __user *__argv,
\tconst char __user *const __user *__envp)
{
\tstruct user_arg_ptr argv = { .ptr.native = __argv };
\tstruct user_arg_ptr envp = { .ptr.native = __envp };
\treturn do_execveat_common(AT_FDCWD, filename, argv, envp, 0);
}""",
        EXEC_DECL + """int do_execve(struct filename *filename,
\tconst char __user *const __user *__argv,
\tconst char __user *const __user *__envp)
{
\tstruct user_arg_ptr argv = { .ptr.native = __argv };
\tstruct user_arg_ptr envp = { .ptr.native = __envp };
""" + EXEC_CALL + """\treturn do_execveat_common(AT_FDCWD, filename, argv, envp, 0);
}""",
        "ksu_handle_execveat_sucompat((int *)AT_FDCWD, &filename, NULL,",
        "fs/exec.c do_execve", fails)

    sub(os.path.join(src, "fs/exec.c"),
        """static int compat_do_execve(struct filename *filename,
\tconst compat_uptr_t __user *__argv,
\tconst compat_uptr_t __user *__envp)
{
\tstruct user_arg_ptr argv = {
\t\t.is_compat = true,
\t\t.ptr.compat = __argv,
\t};
\tstruct user_arg_ptr envp = {
\t\t.is_compat = true,
\t\t.ptr.compat = __envp,
\t};
\treturn do_execveat_common(AT_FDCWD, filename, argv, envp, 0);
}""",
        """static int compat_do_execve(struct filename *filename,
\tconst compat_uptr_t __user *__argv,
\tconst compat_uptr_t __user *__envp)
{
\tstruct user_arg_ptr argv = {
\t\t.is_compat = true,
\t\t.ptr.compat = __argv,
\t};
\tstruct user_arg_ptr envp = {
\t\t.is_compat = true,
\t\t.ptr.compat = __envp,
\t};
""" + COMPAT_EXEC_CALL + """\treturn do_execveat_common(AT_FDCWD, filename, argv, envp, 0);
}""",
        "/* 32-bit su */",
        "fs/exec.c compat_do_execve", fails)

    # 2. faccessat: `su` existence probes from the manager / apps.
    sub(os.path.join(src, "fs/open.c"),
        """SYSCALL_DEFINE3(faccessat, int, dfd, const char __user *, filename, int, mode)
{
\tconst struct cred *old_cred;""",
        """#ifdef CONFIG_KSU
extern int ksu_handle_faccessat(int *dfd, const char __user **filename_user,
\t\t\t\tint *mode, int *__unused_flags);
#endif

SYSCALL_DEFINE3(faccessat, int, dfd, const char __user *, filename, int, mode)
{
#ifdef CONFIG_KSU
\tksu_handle_faccessat(&dfd, &filename, &mode, NULL);
#endif
\tconst struct cred *old_cred;""",
        "ksu_handle_faccessat(&dfd, &filename, &mode, NULL)", "fs/open.c faccessat", fails)

    # 3. read: ksud fd handoff to init. Without it only the su binary path works,
    #    ksud's daemon cannot be launched from init.
    sub(os.path.join(src, "fs/read_write.c"),
        """SYSCALL_DEFINE3(read, unsigned int, fd, char __user *, buf, size_t, count)
{
\tstruct fd f = fdget_pos(fd);""",
        """#ifdef CONFIG_KSU
extern bool ksu_vfs_read_hook __read_mostly;
extern int ksu_handle_sys_read(unsigned int fd, char __user **buf_ptr,
\t\t\t       size_t *count_ptr);
#endif

SYSCALL_DEFINE3(read, unsigned int, fd, char __user *, buf, size_t, count)
{
#ifdef CONFIG_KSU
\tif (unlikely(ksu_vfs_read_hook))
\t\tksu_handle_sys_read(fd, &buf, &count);
#endif
\tstruct fd f = fdget_pos(fd);""",
        "ksu_handle_sys_read(fd, &buf, &count)", "fs/read_write.c read", fails)

    # 4. vfs_statx: su stat() spoof. ksud's own stat checks need it.
    sub(os.path.join(src, "fs/stat.c"),
        "int vfs_statx(int dfd, const char __user *filename, int flags,",
        """#ifdef CONFIG_KSU
extern int ksu_handle_stat(int *dfd, const char __user **filename_user,
\t\t\t   int *flags);
#endif

int vfs_statx(int dfd, const char __user *filename, int flags,""",
        "extern int ksu_handle_stat", "fs/stat.c decl", fails)

    sub(os.path.join(src, "fs/stat.c"),
        """\tstruct path path;
\tint error = -EINVAL;
\tunsigned int lookup_flags = LOOKUP_FOLLOW | LOOKUP_AUTOMOUNT;

\tif ((flags & ~(AT_SYMLINK_NOFOLLOW | AT_NO_AUTOMOUNT |""",
        """\tstruct path path;
\tint error = -EINVAL;
\tunsigned int lookup_flags = LOOKUP_FOLLOW | LOOKUP_AUTOMOUNT;

#ifdef CONFIG_KSU
\tksu_handle_stat(&dfd, &filename, &flags);
#endif

\tif ((flags & ~(AT_SYMLINK_NOFOLLOW | AT_NO_AUTOMOUNT |""",
        "ksu_handle_stat(&dfd, &filename, &flags)", "fs/stat.c call", fails)

    # 5. input: volume-down x3 -> su request window (manager convenience,
    #    not required for su itself)
    sub(os.path.join(src, "drivers/input/input.c"),
        """static void input_handle_event(struct input_dev *dev,
\t\t\t       unsigned int type, unsigned int code, int value)
{
""",
        """#ifdef CONFIG_KSU
extern int ksu_handle_input_handle_event(unsigned int *type,
\t\t\t\t\t unsigned int *code, int *value);
#endif

static void input_handle_event(struct input_dev *dev,
\t\t\t       unsigned int type, unsigned int code, int value)
{
#ifdef CONFIG_KSU
\tksu_handle_input_handle_event(&type, &code, &value);
#endif
""",
        "ksu_handle_input_handle_event(&type, &code, &value)",
        "drivers/input/input.c", fails)

    # 6. pts_unix98_lookup: su terminal gets the ksu devpts sid.
    sub(os.path.join(src, "drivers/tty/pty.c"),
        """\tstruct tty_struct *tty;

\tmutex_lock(&devpts_mutex);
\ttty = devpts_get_priv(file->f_path.dentry);""",
        """\tstruct tty_struct *tty;

#ifdef CONFIG_KSU
\t{
\t\textern int ksu_handle_devpts(struct inode *);
\t\tksu_handle_devpts((struct inode *)file->f_path.dentry->d_inode);
\t}
#endif
\tmutex_lock(&devpts_mutex);
\ttty = devpts_get_priv(file->f_path.dentry);""",
        "ksu_handle_devpts((struct inode *)file->f_path.dentry->d_inode)",
        "drivers/tty/pty.c devpts", fails)

    print("hooks: %d unresolved" % len(fails))
    for x in fails:
        print("   FAIL", x)
    return 1 if fails else 0


# ----------------------------------------------------------------- ksuside
def cmd_ksuside(ksu):
    fails = []

    # 10_enable already patched ksu.c/core_hook.c/sucompat.c, but the SUSFS
    # snapshot we ship must be reachable from every TU that uses it, and
    # kernelsu_init() must call susfs_init() before ksu_core_init().
    for rel, label in [("kernel/ksu.c", "ksu.c"),
                       ("kernel/core_hook.c", "core_hook.c"),
                       ("kernel/allowlist.c", "allowlist.c")]:
        p = os.path.join(ksu, rel)
        if not os.path.isfile(p):
            fails.append("MISS FILE %s" % rel)
            continue
        s = read(p)
        if "linux/susfs.h" in s:
            print("  skip  %s susfs.h" % label)
            continue
        anchor = None
        for cand in ("#include <linux/sched.h>", "#include <linux/version.h>",
                     "#include <linux/cred.h>", "#include <linux/types.h>"):
            if cand in s:
                anchor = cand
                break
        if anchor is None:
            fails.append("MISS ANCHOR %s include" % rel)
            continue
        write(p, s.replace(anchor, anchor + "\n#ifdef CONFIG_KSU_SUSFS\n#include <linux/susfs.h>\n#endif", 1))
        print("  ok    %s susfs.h" % label)

    p = os.path.join(ksu, "kernel/core_hook.c")
    if os.path.isfile(p):
        s = read(p)
        if "linux/susfs_def.h" not in s and "#include <linux/susfs.h>" in s:
            write(p, s.replace("#include <linux/susfs.h>",
                               "#include <linux/susfs.h>\n#include <linux/susfs_def.h>", 1))
            print("  ok    core_hook.c susfs_def.h")

    # kernelsu_init() -> susfs_init() must run before ksu_core_init() so the
    # /proc handlers exist before the first prctl arrives.
    p = os.path.join(ksu, "kernel/ksu.c")
    if os.path.isfile(p):
        s = read(p)
        if "susfs_init();" not in s:
            m = re.search(r"int __init kernelsu_init\(void\)\n\{\n", s)
            if m:
                s = s[:m.end()] + "#ifdef CONFIG_KSU_SUSFS\n\tsusfs_init();\n#endif\n" + s[m.end():]
                write(p, s)
                print("  ok    ksu.c susfs_init()")
            else:
                fails.append("MISS ANCHOR ksu.c kernelsu_init")

    # 10_enable assumes ksu_handle_devpts() already exists in sucompat.c; it does
    # in v1.0.5, but assert it so a future KSU bump fails loudly instead of
    # silently producing a kernel with no devpts sid handoff.
    p = os.path.join(ksu, "kernel/sucompat.c")
    if os.path.isfile(p) and "int ksu_handle_devpts(struct inode *inode)" not in read(p):
        s = read(p)
        write(p, s.rstrip("\n") + """

int ksu_handle_devpts(struct inode *inode)
{
\treturn 0;
}
""")
        print("  ok    sucompat.c ksu_handle_devpts stub")

    print("ksuside: %d unresolved" % len(fails))
    for x in fails:
        print("   FAIL", x)
    return 1 if fails else 0


# -------------------------------------------------------------------- gate
def read_config(path):
    cfg = {}
    if not os.path.isfile(path):
        return None
    for line in read(path).split("\n"):
        line = line.strip()
        if line.startswith("# CONFIG_") and line.endswith("is not set"):
            cfg[line[2:].split()[0]] = "n"
        elif line.startswith("CONFIG_") and "=" in line:
            k, v = line.split("=", 1)
            cfg[k] = v.strip('"')
    return cfg


def cmd_gate(src):
    """Assert the module ABI never moved. This is the v14 gate - not FORCE_LOAD."""
    out = os.path.join(src, "out", ".config")
    cfg = read_config(out)
    if cfg is None:
        print("  NO .config at %s" % out)
        return 1
    bad = []
    for k, v in sorted(ABI_LOCK.items()):
        got = cfg.get(k, "<absent>")
        ok = got == v
        if not ok:
            bad.append(k)
        print("  %-34s want=%-6s got=%-10s %s" % (k, v, got, "OK" if ok else "FAIL"))
    print()
    # KSU / SUSFS must be built in, never modules
    for k in ("CONFIG_KSU", "CONFIG_KSU_SUSFS"):
        got = cfg.get(k, "<absent>")
        ok = got == "y"
        if not ok:
            bad.append(k)
        print("  %-34s want=y      got=%-10s %s" % (k, got, "OK" if ok else "FAIL"))
    if bad:
        print("""
  The gate above is the module ABI contract. genksyms CRCs are computed from
  type definitions and these CONFIG symbols; flipping any one of them
  regenerates the CRCs in __versions and every prebuilt .ko is rejected with
  "disagrees about version of symbol module_layout".
  CONFIG_MODULE_FORCE_LOAD is asserted =n on purpose: official load_module()
  is the stock implementation, so FORCE_LOAD would only matter for insmod -f,
  which nothing on this device passes.""")
    print("gate: %d problem(s)" % len(bad))
    return 1 if bad else 0


# ------------------------------------------------------------------ verify
CHECKS = [
    ("fs/Makefile", r"obj-\$\(CONFIG_KSU_SUSFS\) \+= susfs\.o", 1),
    ("fs/proc/cmdline.c", r"susfs_spoof_cmdline_or_bootconfig", 2),
    ("fs/proc/task_mmu.c", r"extern void susfs_sus_ino_for_show_map_vma", 1),
    ("fs/proc/task_mmu.c", r"susfs_sus_ino_for_show_map_vma\(inode->i_ino", 1),
    ("fs/stat.c", r"extern void susfs_sus_ino_for_generic_fillattr", 1),
    ("fs/stat.c", r"susfs_sus_ino_for_generic_fillattr\(inode->i_ino, stat\)", 1),
    ("fs/stat.c", r"susfs_is_current_non_root_user_app_proc", 1),
    ("kernel/sys.c", r"susfs_spoof_uname", 2),
    ("kernel/kallsyms.c", r"CONFIG_KSU_SUSFS_HIDE_KSU_SUSFS_SYMBOLS", 1),
    ("fs/namespace.c", r"void susfs_run_try_umount_for_current_mnt_ns", 1),
    ("fs/namespace.c", r"bool susfs_is_mnt_devname_ksu", 1),
    ("fs/namespace.c", r"^int path_umount\(struct path \*path, int flags\)", 1),
    ("fs/internal.h", r"int path_umount\(struct path \*path, int flags\);", 1),
    ("fs/exec.c", r"ksu_handle_execveat_sucompat", 2),
    ("fs/exec.c", r"/\* 32-bit su \*/", 1),
    ("fs/open.c", r"ksu_handle_faccessat", 2),
    ("fs/read_write.c", r"ksu_handle_sys_read", 2),
    ("fs/stat.c", r"ksu_handle_stat", 2),
    ("drivers/input/input.c", r"ksu_handle_input_handle_event", 2),
    ("drivers/tty/pty.c", r"ksu_handle_devpts", 2),
    ("fs/susfs.c", r'susfs is initialized! version: " SUSFS_VERSION', 1),
    ("include/linux/susfs.h", r'#define SUSFS_VERSION "', 1),
    ("include/linux/susfs_def.h", r"TIF_NON_ROOT_USER_APP_PROC", 1),
    ("drivers/kernelsu/Kconfig", r"config KSU_SUSFS\b", 1),
    ("drivers/kernelsu/core_hook.c", r"susfs_run_try_umount_for_current_mnt_ns", 1),
    ("drivers/kernelsu/core_hook.c", r"linux/susfs_def\.h", 1),
    ("drivers/kernelsu/selinux/selinux.c", r"susfs_is_current_ksu_domain", 1),
    ("drivers/kernelsu/sucompat.c", r"int ksu_handle_devpts", 1),
    ("drivers/kernelsu/ksud.c", r"int ksu_handle_sys_read", 1),
    ("drivers/kernelsu/ksud.c", r"int ksu_handle_input_handle_event", 1),
    ("drivers/kernelsu/ksu.c", r"int ksu_handle_execveat", 1),
    ("drivers/kernelsu/ksu.c", r"susfs_init\(\);", 1),
]


def cmd_verify(src):
    bad = 0
    for rel, pat, n in CHECKS:
        p = os.path.join(src, rel)
        if not os.path.isfile(p):
            print("  MISSING  %s" % rel)
            bad += 1
            continue
        c = len(re.findall(pat, read(p), re.M))
        if c < n:
            print("  SHORT    %-42s %-44s want>=%d got %d" % (rel, pat[:44], n, c))
            bad += 1
        else:
            print("  ok       %-42s %s" % (rel, pat[:42]))
    print("verify: %d problem(s)" % bad)
    return 1 if bad else 0


# ------------------------------------------------------------------ compat
# Three KernelSU v1.0.5 kernel sources reference helpers that exist upstream
# but not in the official nabu-r-oss 4.14.180 tree. Each was verified absent by
# grepping the actual headers (see the yml comment block). Without these the
# build dies in drivers/kernelsu, not in the SUSFS code.
COMPAT_FIXES = [
    (
        "kernel/ksu.c",
        "MODULE_IMPORT_NS(VFS_internal_I_am_really_a_filesystem_and_am_NOT_a_driver);\n",
        "/* 4.14 has no symbol namespaces: MODULE_IMPORT_NS is 5.4+ */\n",
        "4.14 has no symbol namespaces",
        "ksu.c drop symbol-namespace import",
    ),
    (
        "kernel/kernel_compat.c",
        """long ksu_strncpy_from_user_nofault(char *dst, const void __user *unsafe_addr,
\t\t\t\t   long count)
{
\treturn strncpy_from_user_nofault(dst, unsafe_addr, count);
}""",
        """long ksu_strncpy_from_user_nofault(char *dst, const void __user *unsafe_addr,
\t\t\t\t   long count)
{
\t/* strncpy_from_user_nofault() is 5.8+. 4.14 only has strncpy_from_unsafe(),
\t * which skips the access_ok() check, so do it here - without it a caller
\t * could hand us a kernel pointer and copy kernel memory into kernel
\t * scratch space. */
\tif (!ksu_access_ok(unsafe_addr, count))
\t\treturn -EFAULT;
\treturn strncpy_from_unsafe(dst, unsafe_addr, count);
}""",
        "ksu_access_ok(unsafe_addr, count)",
        "kernel_compat.c strncpy_from_unsafe + access_ok",
    ),
]


def cmd_compat(ksu):
    fails = []
    for rel, find, repl, marker, label in COMPAT_FIXES:
        path = os.path.join(ksu, rel)
        if not os.path.isfile(path):
            fails.append("MISS FILE %s" % rel)
            continue
        src = read(path)
        if marker in src:
            print("  skip  %s" % label)
            continue
        if find not in src:
            fails.append("MISS ANCHOR %s" % rel)
            continue
        write(path, src.replace(find, repl, 1))
        print("  ok    %s" % label)

    # get_cred_rcu: 10_enable adds it with a sed on include/linux/cred.h; verify
    # it really landed, because core_hook.c calls it unconditionally.
    print("compat: %d unresolved" % len(fails))
    for x in fails:
        print("   FAIL", x)
    return 1 if fails else 0


def cmd_compatcheck(src):
    """Assert the three 4.14-compat shims are in place."""
    bad = 0
    ksu = os.path.join(src, "drivers", "kernelsu")
    # drivers/kernelsu IS the KSU kernel/ directory, so paths are bare names here
    checks = [
        ("ksu.c", r"MODULE_IMPORT_NS\s*\(", 0, "symbol-namespace macro must not be called"),
        ("kernel_compat.c", r"return strncpy_from_user_nofault\s*\(", 0,
         "must not call the 5.8+ helper"),
        ("kernel_compat.c", r"return strncpy_from_unsafe\s*\(", 1,
         "must call the 4.14 helper"),
        ("core_hook.c", r"get_cred_rcu", 1, "get_cred_rcu is called"),
    ]
    for rel, pat, want, note in checks:
        p = os.path.join(ksu, rel)
        if not os.path.isfile(p):
            print("  MISSING  %s" % rel)
            bad += 1
            continue
        n = len(re.findall(pat, read(p)))
        ok = (n == want)
        if not ok:
            bad += 1
        print("  %-34s %-28s got=%d want=%d %s" % (rel, pat, n, want, "OK" if ok else "FAIL"))
    # cred.h get_cred_rcu is injected by 10_enable's Makefile sed at build time,
    # so only assert the injection recipe is still in the KSU Makefile.
    mk = os.path.join(ksu, "Makefile")
    if os.path.isfile(mk) and "get_cred_rcu" in read(mk):
        print("  %-34s %-28s %s" % ("kernel/Makefile", "get_cred_rcu sed", "OK"))
    else:
        print("  %-34s %-28s %s" % ("kernel/Makefile", "get_cred_rcu sed", "FAIL"))
        bad += 1
    print("compatcheck: %d problem(s)" % bad)
    return 1 if bad else 0


# ----------------------------------------------------------------- wiring
# Put drivers/kernelsu into the build. The v13 yml used sed on drivers/Kconfig
# and drivers/Makefile; v14 does it with exact anchors verified against the
# official tree (drivers/Kconfig ends with a single 'endmenu', drivers/Makefile
# ends with the GNSS obj-$(CONFIG_GNSS) line).
def cmd_wiring(src):
    fails = []
    mk = os.path.join(src, "drivers", "Makefile")
    kc = os.path.join(src, "drivers", "Kconfig")

    if not os.path.isfile(mk):
        fails.append("MISS FILE drivers/Makefile")
    else:
        s = read(mk)
        if "kernelsu/" not in s:
            anchor = "obj-$(CONFIG_GNSS)		+= gnss/"
            if anchor not in s:
                fails.append("MISS ANCHOR drivers/Makefile GNSS")
            else:
                s = s.replace(anchor, anchor + "\nobj-$(CONFIG_KSU) += kernelsu/", 1)
                write(mk, s)
                print("  ok    drivers/Makefile kernelsu/")
        else:
            print("  skip  drivers/Makefile kernelsu/")

    if not os.path.isfile(kc):
        fails.append("MISS FILE drivers/Kconfig")
    else:
        s = read(kc)
        if "drivers/kernelsu/Kconfig" not in s:
            # insert before the final endmenu (the drivers menu close)
            idx = s.rfind("endmenu")
            if idx < 0:
                fails.append("MISS ANCHOR drivers/Kconfig endmenu")
            else:
                s = s[:idx] + 'source "drivers/kernelsu/Kconfig"\n\n' + s[idx:]
                write(kc, s)
                print("  ok    drivers/Kconfig source kernelsu")
        else:
            print("  skip  drivers/Kconfig source kernelsu")

    print("wiring: %d unresolved" % len(fails))
    for x in fails:
        print("   FAIL", x)
    return 1 if fails else 0


def cmd_wiringcheck(src):
    bad = 0
    for rel, pat, want in [
        ("drivers/Makefile", r"obj-\$\(CONFIG_KSU\) \+= kernelsu/", 1),
        ("drivers/Kconfig", r'source "drivers/kernelsu/Kconfig"', 1),
    ]:
        p = os.path.join(src, rel)
        if not os.path.isfile(p):
            print("  MISSING  %s" % rel)
            bad += 1
            continue
        n = len(re.findall(pat, read(p)))
        ok = (n == want)
        if not ok:
            bad += 1
        print("  %-24s %-40s got=%d want=%d %s" % (rel, pat[:40], n, want, "OK" if ok else "FAIL"))
    print("wiringcheck: %d problem(s)" % bad)
    return 1 if bad else 0


# ----------------------------------------------------------- sepolicy14
# KernelSU v1.0.5 ships drivers/kernelsu/selinux/sepolicy.c written for
# >=5.9 SELinux internals. Two functions reference things that simply do
# not exist in 4.14 and are NOT behind a version guard upstream:
#
#   add_filename_trans()  uses struct filename_trans_key,
#                         policydb_filenametr_search(), the stypes ebitmap,
#                         trans->next and a 4-argument hashtab_insert().
#                         4.14 has struct filename_trans {stype,ttype,tclass,name},
#                         a datum with only otype, and 3-argument hashtab_insert().
#   add_type()            uses db->type_val_to_struct as a ** array.
#                         4.14 declares it as struct flex_array
#                         (*type_val_to_struct_array).
#
# Both are reachable only at runtime through ksud's ioctl path
# (core_hook.c -> ksu_handle_sepolicy -> CMD_TYPE / CMD_TYPE_TRANSITION), i.e.
# when the manager pushes sepolicy rules after boot. Neither touches module
# loading, vermagic or any exported symbol CRC, so degrading them to a no-op on
# 4.14 costs a runtime rule-injection path, not correctness of the build.
#
# This wraps each definition in
#     #if LINUX_VERSION_CODE >= KERNEL_VERSION(5,9,0) ... #else <no-op> #endif
# and is idempotent: it detects the marker and skips.


def _fn_span(src, name):
    """Locate the *definition* of `static bool NAME(` and return (start, end)."""
    pat = re.compile(r'^static bool ' + re.escape(name) + r'\s*\(', re.M)
    for m in reversed(list(pat.finditer(src))):
        k = m.start()
        p = src.index('(', k)
        d = 0
        q = p
        while q < len(src):
            if src[q] == '(':
                d += 1
            elif src[q] == ')':
                d -= 1
                if d == 0:
                    break
            q += 1
        r = q + 1
        while r < len(src) and src[r] in ' \t\n':
            r += 1
        if r < len(src) and src[r] == '{':
            b = r
            d = 0
            for j in range(b, len(src)):
                if src[j] == '{':
                    d += 1
                elif src[j] == '}':
                    d -= 1
                    if d == 0:
                        return k, j + 1
    return -1, -1


SEPO_FALLBACKS = {
    'add_filename_trans':
        'static bool add_filename_trans(struct policydb *db, const char *s,\n'
        '\t\t\t       const char *t, const char *c, const char *d,\n'
        '\t\t\t       const char *o)\n'
        '{\n'
        '\treturn false;\n'
        '}',
    'add_type':
        'static bool add_type(struct policydb *db, const char *type_name, bool attr)\n'
        '{\n'
        '\treturn false;\n'
        '}',
}


def cmd_sepolicy14(ksu):
    path = os.path.join(ksu, 'kernel', 'selinux', 'sepolicy.c')
    if not os.path.isfile(path):
        print('sepolicy14: MISS FILE %s' % path)
        return 1
    src = read(path)
    marker = '4.14 port: SELinux internal API here is pre-5.9'
    if marker in src:
        print('sepolicy14: already applied')
        return 0

    fails = []
    for name, fallback in SEPO_FALLBACKS.items():
        i, end = _fn_span(src, name)
        if i < 0:
            fails.append('MISS FN %s' % name)
            continue
        body = src[i:end]
        if 'LINUX_VERSION_CODE' in body.split('\n')[0]:
            continue
        src = (src[:i]
               + '#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 9, 0)\n'
               + body
               + '\n#else /* ' + marker + ' */\n'
               + fallback
               + '\n#endif /* LINUX_VERSION_CODE >= KERNEL_VERSION(5, 9, 0) */\n'
               + src[end:])
        print('  ok    wrapped %s' % name)

    if not fails:
        write(path, src)
        # verify nothing 5.9-only escaped the guards
        lines = src.splitlines()

        def depth_at(n):
            d = 0
            for l in lines[:n - 1]:
                t = l.strip()
                if t.startswith('#if'):
                    d += 1
                elif t.startswith('#endif'):
                    d -= 1
            return d

        leaks = []
        for pat in ('filename_trans_key', 'filenametr_key_params',
                    'compat_filename_trans_count', 'db->type_val_to_struct',
                    '->stypes', 'trans->next'):
            for n, l in enumerate(lines, 1):
                if pat in l and depth_at(n) == 0:
                    leaks.append('%s@%d' % (pat, n))
        if leaks:
            print('  FAIL unguarded: %s' % ', '.join(leaks[:8]))
            fails.append('leak')
        else:
            print('  all 5.9-only identifiers are inside the guards')

    print('sepolicy14: %d unresolved' % len(fails))
    for x in fails:
        print('   FAIL', x)
    return 1 if fails else 0



def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    if cmd == "apply10":
        return cmd_apply10(sys.argv[2], sys.argv[3])
    if cmd == "apply50":
        return cmd_apply50(sys.argv[2], sys.argv[3])
    if cmd == "fixups":
        return cmd_fixups(sys.argv[2])
    if cmd == "umount":
        return cmd_umount(sys.argv[2])
    if cmd == "hooks":
        return cmd_hooks(sys.argv[2])
    if cmd == "ksuside":
        return cmd_ksuside(sys.argv[2])
    if cmd == "compat":
        return cmd_compat(sys.argv[2])
    if cmd == "sepolicy14":
        return cmd_sepolicy14(sys.argv[2])
    if cmd == "compatcheck":
        return cmd_compatcheck(sys.argv[2])
    if cmd == "wiring":
        return cmd_wiring(sys.argv[2])
    if cmd == "wiringcheck":
        return cmd_wiringcheck(sys.argv[2])
    if cmd == "gate":
        return cmd_gate(sys.argv[2])
    if cmd == "verify":
        return cmd_verify(sys.argv[2])
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main())
